import styles from './Footer.module.css'

function Footer() {
    return (
        <>
        <footer className={styles.footer}>
            FEITO P0R IAN LUCCA E HUGO LUIZ
        </footer>
        </>
    )
}

export default Footer
